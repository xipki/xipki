For the Utimaco HSM, if you want to use the advanced login mechanism,
  - Change "user" to CKU_CS_GENERIC or the value 0x83.
  - Use "password" in form of <user_name>,<auth_token>. For details please refer to the manual of
    Utimaco's user guide.
